# Merge Pistons (Fabric 1.20.1)

Susunan: sticky piston saling berhadapan, taruh block / mob / item di depan masing-masing piston,
lalu nyalakan lever.

    P B _ B P   (satu ruang kosong di tengah -> hasil muncul di tengah)
    P B B P     (tanpa ruang kosong)

Resep:
- Netherite Block + Netherite Block = Super Netherite
- Bedrock + Netherite Block = Unbreakable Block (tidak bisa dihancurkan, termasuk di creative)
- Sheep (domba) + Cookie (item di tanah) = Coosheep. Klik kanan = makan bulu cookie;
  setelah 6 gigitan dombanya gundul. Bulu tumbuh lagi kalau makan rumput. Gunting = jatuh cookie.

Build jar: upload folder ini ke GitHub, tab Actions -> build, ambil mergepistons-jar di Artifacts.
