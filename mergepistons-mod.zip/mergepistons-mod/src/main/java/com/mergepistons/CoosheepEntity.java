package com.mergepistons;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.DyeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ItemStackParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

/** Domba dengan bulu cookie. Klik kanan = makan bulunya; kalau kebanyakan, dombanya gundul. */
public class CoosheepEntity extends SheepEntity {
    public static final int MAX_BITES = 6;
    private int bites = 0;

    public CoosheepEntity(EntityType<? extends SheepEntity> type, World world) {
        super(type, world);
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        boolean special = stack.isOf(Items.SHEARS) || stack.getItem() instanceof DyeItem;
        if (!special && !this.isSheared() && !this.isBaby()) {
            if (!this.getWorld().isClient) {
                player.getHungerManager().add(2, 0.4f);
                this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.ENTITY_GENERIC_EAT,
                        SoundCategory.NEUTRAL, 1.0f, 1.0f);
                if (this.getWorld() instanceof ServerWorld sw) {
                    sw.spawnParticles(new ItemStackParticleEffect(ParticleTypes.ITEM, new ItemStack(Items.COOKIE)),
                            this.getX(), this.getY() + 0.9, this.getZ(), 8, 0.25, 0.25, 0.25, 0.05);
                }
                bites++;
                if (bites >= MAX_BITES) {
                    bites = 0;
                    this.setSheared(true); // bulu habis, domba gundul
                    this.getWorld().playSound(null, this.getBlockPos(), SoundEvents.ENTITY_SHEEP_SHEAR,
                            SoundCategory.NEUTRAL, 1.0f, 1.0f);
                }
            }
            return ActionResult.success(this.getWorld().isClient);
        }
        return super.interactMob(player, hand);
    }

    /** Pakai gunting: jatuh cookie, bukan wol. */
    @Override
    public void sheared(SoundCategory shearedSoundCategory) {
        this.getWorld().playSoundFromEntity(null, this, SoundEvents.ENTITY_SHEEP_SHEAR, shearedSoundCategory, 1.0f, 1.0f);
        this.setSheared(true);
        this.bites = 0;
        int n = 1 + this.random.nextInt(3);
        for (int i = 0; i < n; i++) {
            ItemEntity e = this.dropStack(new ItemStack(Items.COOKIE), 1.0f);
            if (e != null) {
                e.setVelocity(e.getVelocity().add((this.random.nextFloat() - this.random.nextFloat()) * 0.1f,
                        this.random.nextFloat() * 0.05f, (this.random.nextFloat() - this.random.nextFloat()) * 0.1f));
            }
        }
    }

    @Override
    public void onEatingGrass() {
        super.onEatingGrass(); // bulu tumbuh lagi
        this.bites = 0;
    }

    @Override
    public SheepEntity createChild(ServerWorld world, PassiveEntity entity) {
        return MergePistonsMod.COOSHEEP.create(world);
    }

    @Override
    public Identifier getLootTableId() {
        return this.getType().getLootTableId();
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Bites", bites);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        bites = nbt.getInt("Bites");
    }
}
