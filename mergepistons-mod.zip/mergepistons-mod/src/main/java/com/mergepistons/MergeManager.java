package com.mergepistons;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PistonBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.List;

/**
 * Dua sticky piston saling berhadapan.
 *   P B _ B P  (ada 1 ruang kosong di tengah)  -> hasil muncul di tengah
 *   P B B P    (tanpa ruang kosong)            -> hasil muncul di tempat block pertama
 * "B" bisa block atau mob/item.
 */
public final class MergeManager {
    private MergeManager() {}

    /** @return 0 = tidak ada fusi, 2/3 = jumlah sel di antara dua piston saat fusi terjadi */
    public static int tryMerge(World world, BlockPos pos, BlockState state) {
        if (!(world instanceof ServerWorld sw)) return 0;
        if (!state.isOf(Blocks.STICKY_PISTON) || state.get(PistonBlock.EXTENDED)) return 0;
        if (!world.isReceivingRedstonePower(pos) && !world.isReceivingRedstonePower(pos.up())) return 0;

        Direction dir = state.get(PistonBlock.FACING);
        for (int k = 3; k >= 2; k--) {
            BlockPos other = pos.offset(dir, k + 1);
            BlockState os = world.getBlockState(other);
            if (!os.isOf(Blocks.STICKY_PISTON) || os.get(PistonBlock.EXTENDED)
                    || os.get(PistonBlock.FACING) != dir.getOpposite()) continue;

            BlockPos c1 = pos.offset(dir);
            BlockPos c2 = other.offset(dir.getOpposite());
            BlockPos mid = (k == 3) ? pos.offset(dir, 2) : c1;
            if (k == 3 && !world.getBlockState(mid).isAir()) continue;

            if (merge(sw, c1, c2, mid)) return k;
        }
        return 0;
    }

    private static boolean merge(ServerWorld sw, BlockPos c1, BlockPos c2, BlockPos mid) {
        // 1) block + block
        Block a = sw.getBlockState(c1).getBlock();
        Block b = sw.getBlockState(c2).getBlock();
        Block result = blockRecipe(a, b);
        if (result != null) {
            sw.setBlockState(c1, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            sw.setBlockState(c2, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            sw.setBlockState(mid, result.getDefaultState(), Block.NOTIFY_ALL);
            effects(sw, mid);
            return true;
        }
        // 2) mob / item
        List<Entity> l1 = entitiesIn(sw, c1);
        List<Entity> l2 = entitiesIn(sw, c2);
        for (Entity x : l1) {
            for (Entity y : l2) {
                if (sheepCookie(sw, x, y, mid) || sheepCookie(sw, y, x, mid)) {
                    effects(sw, mid);
                    return true;
                }
            }
        }
        return false;
    }

    private static Block blockRecipe(Block a, Block b) {
        if (pair(a, b, Blocks.BEDROCK, Blocks.NETHERITE_BLOCK)) return MergePistonsMod.UNBREAKABLE_BLOCK;
        if (a == Blocks.NETHERITE_BLOCK && b == Blocks.NETHERITE_BLOCK) return MergePistonsMod.SUPER_NETHERITE;
        return null;
    }

    private static boolean pair(Block a, Block b, Block x, Block y) {
        return (a == x && b == y) || (a == y && b == x);
    }

    private static boolean sheepCookie(ServerWorld sw, Entity sheep, Entity item, BlockPos mid) {
        if (sheep.getType() != EntityType.SHEEP || !(item instanceof ItemEntity ie)) return false;
        if (!ie.getStack().isOf(Items.COOKIE)) return false;
        SheepEntity old = (SheepEntity) sheep;
        CoosheepEntity c = MergePistonsMod.COOSHEEP.create(sw);
        if (c == null) return false;
        c.refreshPositionAndAngles(mid.getX() + 0.5, mid.getY(), mid.getZ() + 0.5, old.getYaw(), 0.0f);
        if (old.isBaby()) c.setBaby(true);
        if (old.hasCustomName()) c.setCustomName(old.getCustomName());
        c.setSheared(false);
        sw.spawnEntity(c);
        old.discard();
        ie.getStack().decrement(1);
        if (ie.getStack().isEmpty()) ie.discard();
        return true;
    }

    private static List<Entity> entitiesIn(ServerWorld sw, BlockPos cell) {
        return sw.getEntitiesByClass(Entity.class, new Box(cell).expand(0.5),
                e -> e.isAlive() && e.getBlockPos().equals(cell));
    }

    private static void effects(ServerWorld sw, BlockPos mid) {
        sw.playSound(null, mid, SoundEvents.BLOCK_PISTON_EXTEND, SoundCategory.BLOCKS, 1.0f, 0.8f);
        sw.playSound(null, mid, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.BLOCKS, 0.6f, 1.2f);
        sw.spawnParticles(ParticleTypes.END_ROD, mid.getX() + 0.5, mid.getY() + 0.5, mid.getZ() + 0.5,
                30, 0.4, 0.4, 0.4, 0.05);
        sw.spawnParticles(ParticleTypes.CLOUD, mid.getX() + 0.5, mid.getY() + 0.5, mid.getZ() + 0.5,
                12, 0.3, 0.3, 0.3, 0.02);
    }
}
