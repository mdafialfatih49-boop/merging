package com.mergepistons.client;

import com.mergepistons.CoosheepEntity;
import com.mergepistons.MergePistonsMod;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.EntityModelLoader;
import net.minecraft.client.render.entity.model.SheepEntityModel;
import net.minecraft.client.render.entity.model.SheepWoolEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Menggambar "bulu" dengan texture cookie (menggantikan wol putih). */
public class CoosheepFurFeature extends FeatureRenderer<CoosheepEntity, SheepEntityModel<CoosheepEntity>> {
    private static final Identifier FUR = MergePistonsMod.id("textures/entity/coosheep/coosheep_fur.png");
    private final SheepWoolEntityModel<CoosheepEntity> furModel;

    public CoosheepFurFeature(FeatureRendererContext<CoosheepEntity, SheepEntityModel<CoosheepEntity>> context,
                              EntityModelLoader loader) {
        super(context);
        this.furModel = new SheepWoolEntityModel<>(loader.getModelPart(EntityModelLayers.SHEEP_FUR));
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                       CoosheepEntity entity, float limbAngle, float limbDistance, float tickDelta,
                       float animationProgress, float headYaw, float headPitch) {
        if (entity.isSheared() || entity.isInvisible()) return;
        this.getContextModel().copyStateTo(this.furModel);
        this.furModel.animateModel(entity, limbAngle, limbDistance, tickDelta);
        this.furModel.setAngles(entity, limbAngle, limbDistance, animationProgress, headYaw, headPitch);
        VertexConsumer vc = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(FUR));
        this.furModel.render(matrices, vc, light, LivingEntityRenderer.getOverlay(entity, 0.0f), 1.0f, 1.0f, 1.0f, 1.0f);
    }
}
